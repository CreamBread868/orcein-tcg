const CONFIG = {
  SPREADSHEET_ID: '', // 空欄なら、このGASプロジェクトに紐づくスプレッドシートを使用
  CARD_SHEET: 'Cards',
  DECK_SHEET: 'Decks',
  IMAGE_FOLDER_NAME: 'OriginalTCG_CardImages'
};

const CARD_HEADERS = [
  'id','name','category','type','rarity','image','hp',
  'abilityName','abilityText',
  'attack1Name','attack1Damage','attack1Energy','attack1Text',
  'attack2Name','attack2Damage','attack2Energy','attack2Text',
  'weakness','resistance','retreat','description',
  'abilityCode','attack1Code','attack2Code',
  'imageScale','imageFit','imageY','imageX','imageHeight','artLayout'
];

const DECK_HEADERS = [
  'id', 'name', 'description', 'totalCount', 'cardsJson', 'updatedAt'
];

/**
 * doGet — GASウェブアプリのエントリポイント。
 *
 * ビルド済みの単一HTML (index_local.html) を配信することで、
 * GASテンプレートエンジンが JavaScript の ${...} 構文と干渉するのを防ぐ。
 * デプロイ前に必ず `node build_local.js` を実行してから clasp push すること。
 */
function doGet() {
  try {
    ensureCardSheet_();
    ensureDeckSheet_();
  } catch (e) {
    console.warn('Sheet initialization error in doGet:', e);
  }
  return HtmlService.createHtmlOutputFromFile('index_local')
    .setTitle('ORBITAL TCG')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

/**
 * include() — Index.html の <?!= include('FileName'); ?> から呼ばれる。
 * ローカル確認用。GAS本番では doGet が index_local を直接配信するため不使用。
 */
function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function getSpreadsheet_() {
  if (CONFIG.SPREADSHEET_ID) {
    return SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
  }
  const active = SpreadsheetApp.getActiveSpreadsheet();
  if (!active) throw new Error('スプレッドシートが見つかりません。CONFIG.SPREADSHEET_IDを設定してください。');
  return active;
}

function ensureCardSheet_() {
  const ss = getSpreadsheet_();
  let sheet = ss.getSheetByName(CONFIG.CARD_SHEET);
  if (!sheet) sheet = ss.insertSheet(CONFIG.CARD_SHEET);

  const lastCol = sheet.getLastColumn();
  if (lastCol === 0) {
    sheet.getRange(1, 1, 1, CARD_HEADERS.length).setValues([CARD_HEADERS]);
    sheet.setFrozenRows(1);
    return sheet;
  }

  const existingHeaders = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  const missingHeaders = CARD_HEADERS.filter(h => !existingHeaders.includes(h));
  if (missingHeaders.length > 0) {
    sheet.getRange(1, lastCol + 1, 1, missingHeaders.length).setValues([missingHeaders]);
  }
  return sheet;
}

function ensureDeckSheet_() {
  const ss = getSpreadsheet_();
  let sheet = ss.getSheetByName(CONFIG.DECK_SHEET);
  if (!sheet) sheet = ss.insertSheet(CONFIG.DECK_SHEET);

  const range = sheet.getRange(1, 1, 1, DECK_HEADERS.length);
  const values = range.getValues()[0];
  const matches = DECK_HEADERS.every((h, i) => values[i] === h);
  if (!matches) {
    sheet.clear();
    sheet.getRange(1, 1, 1, DECK_HEADERS.length).setValues([DECK_HEADERS]);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

/* ---------- カード・デッキCRUD ---------- */

function getDecks() {
  const sheet = ensureDeckSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return [];

  const rows = sheet.getRange(2, 1, lastRow - 1, DECK_HEADERS.length).getValues();
  return rows
    .filter(row => row.some(v => v !== ''))
    .map(rowToDeck_);
}

function getDeck(deckId) {
  if (!deckId) return null;
  return getDecks().find(deck => String(deck.id) === String(deckId)) || null;
}

function saveDeck(deck, adminToken) {
  requireAdmin_(adminToken);
  if (!deck || !String(deck.name || '').trim()) {
    throw new Error('デッキ名は必須です。');
  }

  const normalized = normalizeDeck_(deck);
  const sheet = ensureDeckSheet_();
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);

  try {
    const lastRow = sheet.getLastRow();
    const rows = lastRow >= 2
      ? sheet.getRange(2, 1, lastRow - 1, DECK_HEADERS.length).getValues()
      : [];

    const existingIndex = rows.findIndex(row => String(row[0]) === String(normalized.id));

    if (existingIndex >= 0) {
      sheet.getRange(existingIndex + 2, 1, 1, DECK_HEADERS.length)
        .setValues([deckToRow_(normalized)]);
      return {ok: true, mode: 'updated', deck: normalized};
    }

    sheet.appendRow(deckToRow_(normalized));
    return {ok: true, mode: 'created', deck: normalized};
  } finally {
    lock.releaseLock();
  }
}

function deleteDeck(deckId, adminToken) {
  requireAdmin_(adminToken);
  if (!deckId) throw new Error('デッキIDがありません。');

  const sheet = ensureDeckSheet_();
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);

  try {
    const lastRow = sheet.getLastRow();
    if (lastRow < 2) return {ok: false, message: 'デッキがありません。'};

    const ids = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
    const index = ids.findIndex(row => String(row[0]) === String(deckId));
    if (index < 0) return {ok: false, message: 'デッキが見つかりません。'};

    sheet.deleteRow(index + 2);
    return {ok: true};
  } finally {
    lock.releaseLock();
  }
}

function getCards() {
  const sheet = ensureCardSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return [];

  const rows = sheet.getRange(2, 1, lastRow - 1, CARD_HEADERS.length).getValues();
  return rows
    .filter(row => row.some(v => v !== ''))
    .map(rowToCard_);
}

function getCard(id) {
  if (!id) return null;
  return getCards().find(card => String(card.id) === String(id)) || null;
}

function hashPassword_(password) {
  const bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, String(password), Utilities.Charset.UTF_8);
  return bytes.map(b => (b < 0 ? b + 256 : b).toString(16).padStart(2, '0')).join('');
}

// 初回だけApps Scriptエディタから setupAdminPassword('任意のパスワード') を実行してください。
function setupAdminPassword(password) {
  password = password || '3838';
  if (String(password).length < 4) throw new Error('管理者パスワードは4文字以上にしてください。');
  PropertiesService.getScriptProperties().setProperty('ADMIN_PASSWORD_HASH', hashPassword_(password));
  return '管理者パスワードを設定しました。';
}

function loginAdmin(password) {
  const stored = PropertiesService.getScriptProperties().getProperty('ADMIN_PASSWORD_HASH');
  if (!stored) throw new Error('管理者パスワードが未設定です。Apps Scriptエディタで setupAdminPassword() を一度実行してください。');
  if (hashPassword_(password) !== stored) throw new Error('パスワードが違います。');
  const token = Utilities.getUuid();
  CacheService.getScriptCache().put('ADMIN_SESSION_' + token, '1', 21600);
  return {ok:true, token:token, expiresIn:21600};
}

function logoutAdmin(token) {
  if (token) CacheService.getScriptCache().remove('ADMIN_SESSION_' + token);
  return {ok:true};
}

function requireAdmin_(token) {
  if (!token || CacheService.getScriptCache().get('ADMIN_SESSION_' + token) !== '1') {
    throw new Error('管理者ログインが必要です。');
  }
}

function saveCard(card, adminToken) {
  requireAdmin_(adminToken);
  if (!card || !String(card.name || '').trim()) {
    throw new Error('カード名は必須です。');
  }

  const normalized = normalizeCard_(card);
  const sheet = ensureCardSheet_();
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);

  try {
    const lastRow = sheet.getLastRow();
    const rows = lastRow >= 2
      ? sheet.getRange(2, 1, lastRow - 1, CARD_HEADERS.length).getValues()
      : [];

    const existingIndex = rows.findIndex(row => String(row[0]) === String(normalized.id));

    if (existingIndex >= 0) {
      sheet.getRange(existingIndex + 2, 1, 1, CARD_HEADERS.length)
        .setValues([cardToRow_(normalized)]);
      return {ok: true, mode: 'updated', card: normalized};
    }

    sheet.appendRow(cardToRow_(normalized));
    return {ok: true, mode: 'created', card: normalized};
  } finally {
    lock.releaseLock();
  }
}

function deleteCard(id, adminToken) {
  requireAdmin_(adminToken);
  if (!id) throw new Error('カードIDがありません。');

  const sheet = ensureCardSheet_();
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);

  try {
    const lastRow = sheet.getLastRow();
    if (lastRow < 2) return {ok: false, message: 'カードがありません。'};

    const ids = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
    const index = ids.findIndex(row => String(row[0]) === String(id));
    if (index < 0) return {ok: false, message: 'カードが見つかりません。'};

    sheet.deleteRow(index + 2);
    return {ok: true};
  } finally {
    lock.releaseLock();
  }
}

function createImageFolder_() {
  const folders = DriveApp.getFoldersByName(CONFIG.IMAGE_FOLDER_NAME);
  return folders.hasNext() ? folders.next() : DriveApp.createFolder(CONFIG.IMAGE_FOLDER_NAME);
}

/**
 * base64Data は「data:image/png;base64,...」形式を想定。
 * HTMLから画像ファイルを送る場合に使用。
 */
function uploadCardImage(fileName, mimeType, base64Data, adminToken) {
  requireAdmin_(adminToken);
  if (!base64Data) throw new Error('画像データがありません。');

  const folder = createImageFolder_();
  const raw = String(base64Data).split(',').pop();
  const bytes = Utilities.base64Decode(raw);
  const blob = Utilities.newBlob(bytes, mimeType || 'image/png', fileName || 'card-image');
  const file = folder.createFile(blob);

  // Webアプリで表示しやすいURLを返す。
  // Driveの共有設定は環境に応じて変更してください。
  try {
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  } catch (e) {
    // Workspace等で外部共有が禁止されている場合は、ファイルIDを返す。
  }

  return {
    ok: true,
    id: file.getId(),
    url: 'https://drive.google.com/uc?export=view&id=' + file.getId(),
    name: file.getName()
  };
}

/* ---------- デッキ・バトル用の将来拡張API ---------- */

function createGame(playerDeck) {
  // Phase 5以降でゲーム状態を生成。
  return {
    ok: true,
    gameId: Utilities.getUuid(),
    status: 'waiting',
    playerDeck: playerDeck || null
  };
}

function joinGame(gameId, playerDeck) {
  return {ok: true, gameId: gameId, playerDeck: playerDeck || null};
}

function getGameState(gameId) {
  return {gameId: gameId, status: 'not_started'};
}

function performAction(gameId, action) {
  // Phase 6以降でActionEngineと接続。
  return {ok: true, gameId: gameId, action: action || null};
}

/* ---------- 内部変換 ---------- */

function normalizeCard_(card) {
  const out = {};
  CARD_HEADERS.forEach(key => out[key] = card[key] == null ? '' : card[key]);

  if (!out.id) out.id = 'card_' + Utilities.getUuid().replace(/-/g, '').slice(0, 12);
  out.name = String(out.name).trim();
  out.category = out.category || 'たね';
  out.type = out.type || '無';
  out.rarity = out.rarity || 'N';
  out.hp = toNumberOrBlank_(out.hp);
  out.attack1Damage = toNumberOrBlank_(out.attack1Damage);
  out.attack2Damage = toNumberOrBlank_(out.attack2Damage);
  out.retreat = toNumberOrBlank_(out.retreat);
  ['abilityCode','attack1Code','attack2Code'].forEach(key => {
    out[key] = normalizeEffectCode_(out[key]);
  });
  out.imageScale = toNumberOrBlank_(out.imageScale) !== '' ? Number(out.imageScale) : 100;
  out.imageFit = (out.imageFit === 'contain' || out.imageFit === 'fill') ? out.imageFit : 'cover';
  out.imageY = toNumberOrBlank_(out.imageY) !== '' ? Number(out.imageY) : 50;
  out.imageX = toNumberOrBlank_(out.imageX) !== '' ? Number(out.imageX) : 50;
  out.imageHeight = toNumberOrBlank_(out.imageHeight) !== '' ? Number(out.imageHeight) : '';
  out.artLayout = (out.artLayout === 'full' || out.artLayout === 'wide') ? out.artLayout : 'standard';
  return out;
}

function normalizeEffectCode_(value) {
  if (value === '' || value == null) return '';
  const code = String(value);
  if (code.length > 20000) throw new Error('効果コードは20000文字以内にしてください。');
  if (/\beval\s*\(|Function\s*\(|document\.|window\.|fetch\s*\(|XmlService\b|UrlFetchApp\b|ScriptApp\b/.test(code)) {
    throw new Error('カード効果コードに使用できないAPIが含まれています。');
  }
  return code;
}

function toNumberOrBlank_(value) {
  if (value === '' || value == null) return '';
  const n = Number(value);
  return Number.isFinite(n) ? n : '';
}

function rowToCard_(row) {
  const card = {};
  CARD_HEADERS.forEach((key, i) => card[key] = row[i] == null ? '' : row[i]);
  return card;
}

function cardToRow_(card) {
  return CARD_HEADERS.map(key => card[key] == null ? '' : card[key]);
}

function normalizeDeck_(deck) {
  const out = {};
  out.id = deck.id || ('deck_' + Utilities.getUuid().replace(/-/g, '').slice(0, 12));
  out.name = String(deck.name || '').trim();
  out.description = String(deck.description || '').trim();

  let cards = Array.isArray(deck.cards) ? deck.cards : [];
  if (typeof deck.cardsJson === 'string' && deck.cardsJson && cards.length === 0) {
    try { cards = JSON.parse(deck.cardsJson); } catch (e) {}
  }

  let totalCount = 0;
  const cleanCards = [];
  cards.forEach(c => {
    if (!c || !c.id) return;
    const count = Math.max(1, Math.min(60, Number(c.count) || 1));
    totalCount += count;
    cleanCards.push({ id: String(c.id), count: count });
  });

  out.totalCount = totalCount;
  out.cardsJson = JSON.stringify(cleanCards);
  out.updatedAt = Utilities.formatDate(new Date(), 'JST', 'yyyy-MM-dd HH:mm:ss');
  return out;
}

function rowToDeck_(row) {
  const deck = {};
  DECK_HEADERS.forEach((key, i) => deck[key] = row[i] == null ? '' : row[i]);
  try {
    deck.cards = deck.cardsJson ? JSON.parse(deck.cardsJson) : [];
  } catch (e) {
    deck.cards = [];
  }
  return deck;
}

function deckToRow_(deck) {
  return DECK_HEADERS.map(key => deck[key] == null ? '' : deck[key]);
}

